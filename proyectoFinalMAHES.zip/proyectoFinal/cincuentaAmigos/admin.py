from django.contrib import admin, messages
from .models import *

admin.site.site_header = '50 Amigos'
admin.site.index_title = 'Panel de control 50 Amigos'
admin.site.site_title = 'Panel de control 50 Amigos'

# Register your models here.

class EntradasAdmin(admin.ModelAdmin):
      list_display = ('nombre', 'precio', 'imagen', 'descripcion', 'disponibilidad') # Ahora la interfaz mostrará nombre, precio y su disponibilidad
      search_fields = ('nombre', 'precio','imagen', 'disponibilidad', 'descripcion')
      fields = ('descripcion', 'nombre', 'precio', 'disponibilidad', 'imagen') # Ordenar el orden en el que apareceran los campos a poder editar
      list_editable = ('nombre', 'precio', 'imagen')
      list_display_links = ('disponibilidad', 'descripcion')
      #date_hierarchy = 'variableDateTime' # Debe de ser una variable de tipo DateField o DateTimeField
admin.site.register(Entradas, EntradasAdmin)

class FuerteAdmin(admin.ModelAdmin):
      list_display = ('nombre', 'precio', 'imagen', 'descripcion', 'disponibilidad') # Ahora la interfaz mostrará nombre, precio y su disponibilidad
      search_fields = ('nombre', 'precio','imagen', 'disponibilidad', 'descripcion')
      fields = ('descripcion', 'nombre', 'precio', 'disponibilidad', 'imagen') # Ordenar el orden en el que apareceran los campos a poder editar
      list_editable = ('nombre', 'precio', 'imagen')
      list_display_links = ('disponibilidad', 'descripcion')
admin.site.register(Fuerte, FuerteAdmin)

class BebidasAdmin(admin.ModelAdmin):
      list_display = ('nombre', 'precio', 'imagen', 'descripcion', 'disponibilidad') # Ahora la interfaz mostrará nombre, precio y su disponibilidad
      search_fields = ('nombre', 'precio','imagen', 'disponibilidad', 'descripcion')
      fields = ('descripcion', 'nombre', 'precio', 'disponibilidad', 'imagen') # Ordenar el orden en el que apareceran los campos a poder editar
      list_editable = ('nombre', 'precio', 'imagen')
      list_display_links = ('disponibilidad', 'descripcion')
admin.site.register(Bebidas, BebidasAdmin)

class PostresAdmin(admin.ModelAdmin):
      list_display = ('nombre', 'precio', 'imagen', 'descripcion', 'disponibilidad') # Ahora la interfaz mostrará nombre, precio y su disponibilidad
      search_fields = ('nombre', 'precio','imagen', 'disponibilidad', 'descripcion')
      fields = ('descripcion', 'nombre', 'precio', 'disponibilidad', 'imagen') # Ordenar el orden en el que apareceran los campos a poder editar
      list_editable = ('nombre', 'precio', 'imagen')
      list_display_links = ('disponibilidad', 'descripcion')
admin.site.register(Postres, PostresAdmin)

class HeladoAdmin(admin.ModelAdmin):
      list_display = ('nombre', 'precio', 'imagen', 'descripcion', 'disponibilidad') # Ahora la interfaz mostrará nombre, precio y su disponibilidad
      search_fields = ('nombre', 'precio','imagen', 'disponibilidad', 'descripcion')
      fields = ('descripcion', 'nombre', 'precio', 'disponibilidad', 'imagen') # Ordenar el orden en el que apareceran los campos a poder editar
      list_editable = ('nombre', 'precio', 'imagen')
      list_display_links = ('disponibilidad', 'descripcion')
admin.site.register(Helado, HeladoAdmin)


class CarritoAdmin(admin.ModelAdmin):
    list_display = ('platillo', 'precio', 'cantidad', 'contador', 'mesa') # Ahora la interfaz mostrará platillo, precio y su disponibilidad
    search_fields = ('platillo', 'precio', 'cantidad')
    fields = ('platillo', 'precio', 'cantidad', 'contador', 'mesa') # Ordenar el orden en el que apareceran los campos a poder editar
    list_editable = ('platillo', 'precio')
    list_display_links = ('cantidad', 'contador', 'mesa')
admin.site.register(Carrito, CarritoAdmin)

class OrdenAdmin(admin.ModelAdmin):
    list_display = ('platillo', 'precio', 'cantidad', 'contador', 'mesa') # Ahora la interfaz mostrará platillo, precio y su disponibilidad
    search_fields = ('platillo', 'precio', 'cantidad')
    fields = ('platillo', 'precio', 'cantidad', 'contador', 'mesa') # Ordenar el orden en el que apareceran los campos a poder editar
    list_editable = ('platillo', 'precio')
    list_display_links = ('cantidad', 'contador', 'mesa')
admin.site.register(Orden, OrdenAdmin)