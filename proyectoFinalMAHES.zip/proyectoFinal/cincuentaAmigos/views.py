from django.shortcuts import render, HttpResponse, redirect, get_object_or_404
from django.contrib.auth import authenticate, login as auth_login
from django.contrib.auth import logout
from django.views.generic.edit import CreateView, UpdateView
from django.urls import reverse, path
from django.contrib.auth.decorators import login_required
from django.shortcuts import redirect


from .models import *
from .forms import *

from django.http.response import JsonResponse
from random import randrange

idMesa = 0 # Variable global que nos permitira saber el id de la mesa actual
heladoGanador = ""
contadorHelado = 0

# Create your views here.

"""
Importaremos lo siguiente (para formulario normal)

from django.contrib import messages
form .forms import CustomUserCreationForm
from django.contrib.auth import authenticate, login
from django.contrib.auth.decorators import login_required

Para hacer el formulario normal, haremos la siguiente funcion

def registro(request):
    data = {
        'form': CustomUserCreationForm()
    }
    if request.method == "POST":
        formulario = CustomUserCreationForm(data=request.POST)
        if formulario.is_valid():
                usuario = formulario.save()
                usuario.save()
                user = authenticate(username=formulario.cleaned_data["username"], password=formulario.cleaned_data["password1"])
                login(request, user)
                messages.success(request, "Registro exitoso, inicia sesion")
                return redirect(to="miPrimerApp:index")
            data["form"] = formulario
        return render(request, 'registration/register.html', data)  // registration es el html que esta dentro de registration
"""

class RegistrationView(CreateView):
    template_name = 'registration/register.html'
    form_class = RegistrationForm

    def get_context_data(self, *args, **kwargs):
        context = super(RegistrationView, self).get_context_data(*args, **kwargs)
        context['next'] = self.request.GET.get('next')
        return context

    def get_success_url(self):
        next_url = self.request.POST.get('next')
        success_url = reverse('login')
        if next_url:
            success_url += '?next={}'.format(next_url)

        return success_url

# login de las sesiones de los usuarios
def login(request):
    return render(request, 'accounts.login')

# logout de las sesiones de los usuarios
def logout_view(request):
    logout(request)
    #return redirect('home') # Redirect to a success page.

# class MyLoginView(LoginView):
#     redirect_authenticated_user = True

#     def get_success_url(self):
#         return reverse_lazy('tasks')

#     def form_invalid(self, form):
#         messages.error(self.request,'Invalid username or password')
#         return self.render_to_response(self.get_context_data(form=form))


@login_required(login_url="accounts/login/") # ESTO ES PARA PROTEGER LA VISTA
def index(request):
    current_user = get_object_or_404(Account, pk=request.user.pk)
    global idMesa
    idMesa = current_user.mesa
    # print()
    # Entradas
    entradas = Entradas.objects.filter(disponibilidad=1)
    # Plato fuerte
    platoFuerte = Fuerte.objects.filter(disponibilidad=1)
    # Bebidas
    bebidas = Bebidas.objects.filter(disponibilidad=1)
    # Postres
    postres = Postres.objects.filter(disponibilidad=1)
    # Helado
    helado = Helado.objects.filter(disponibilidad=1)

    #varTodos = Algungrupo.objects.filter()

    return render(request, 'index.html', {'entradas':entradas, 'platoFuerte':platoFuerte, 'bebidas':bebidas, 'postres':postres, 'helado':helado})

# Es para obtener informacion del usuario (o admin) que esta loggeado.
def usuario(request):
    user = idMesa
    print(varVotacion)
    return (request, {'user':user, 'varVotacion':varVotacion})

# BEGIN CATEGORIAS DE PLATILLOS
# Entradas
@login_required() # ESTO ES PARA PROTEGER LA VISTA
def entradas(request):
    entradas = Entradas.objects.filter(disponibilidad=1)
    return render(request, 'entradas.html', {'entradas':entradas})

# Plato fuerte
@login_required() # ESTO ES PARA PROTEGER LA VISTA
def fuerte(request):
    fuerte = Fuerte.objects.filter(disponibilidad=1)
    return render(request, 'fuerte.html', {'fuerte':fuerte})

# Postres
@login_required() # ESTO ES PARA PROTEGER LA VISTA
def postres(request):
    postres = Postres.objects.filter(disponibilidad=1)
    return render(request, 'postres.html', {'postres':postres})

# Bebidas
@login_required() # ESTO ES PARA PROTEGER LA VISTA
def bebidas(request):
    bebidas = Bebidas.objects.filter(disponibilidad=1)
    return render(request, 'bebidas.html', {'bebidas':bebidas})

# Helado
@login_required() # ESTO ES PARA PROTEGER LA VISTA
def helado(request):
    helado = Helado.objects.filter(disponibilidad=1)
    return render(request, 'helado.html', {'helado':helado})
# END CAATEGORIAS DE PLATILLOS

"""
 __lte -> Less than or equal
 __gte -> Greater than or equal
 __lt -> Less than
 __gt -> Greater than
"""

# Funcion que devuelve el carrito de pedidos actual, y la orden completa
@login_required() # ESTO ES PARA PROTEGER LA VISTA
def carrito(request):
    carrito = Carrito.objects.filter(mesa=idMesa)
    orden = Orden.objects.filter(mesa=idMesa)
    return render(request, 'carrito.html', {'carrito':carrito, 'orden':orden})

# Funcion que renderiza a voto html
@login_required() # ESTO ES PARA PROTEGER LA VISTA
def voto(request):
    return render(request, 'voto.html')


# BEGIN Eliminar y Agregar de carrito
# Elimina un platillo seleccionado del modelo Carrito y del modelo Orden
def eliminar_platillo(request, id, mesa):
    platillo = Carrito.objects.get(id=id, mesa=mesa) # Eliminar platillo
    platillo.delete()
    return redirect('/carrito')

# Agrega platillo como un objeto al modelo Carrito
# **ENTRADAS*
def agregar_platilloE(request, platillo, precio, cantidad, mesa):
    cantidad = nuevo_platillo(platillo, Carrito, 1)
    platillo = Carrito.objects.create(platillo=platillo, precio=precio, cantidad=cantidad, mesa=mesa, parcial=1)
    return redirect('/entradas')
# **FUERTE*
def agregar_platilloF(request, platillo, precio, cantidad, mesa):
    cantidad = nuevo_platillo(platillo, Carrito, 1)
    platillo = Carrito.objects.create(platillo=platillo, precio=precio, cantidad=cantidad, mesa=mesa, parcial=1)
    return redirect('/fuerte')
# **BEBIDAS*
def agregar_platilloB(request, platillo, precio, cantidad, mesa):
    cantidad = nuevo_platillo(platillo, Carrito, 1)
    platillo = Carrito.objects.create(platillo=platillo, precio=precio, cantidad=cantidad, mesa=mesa, parcial=1)
    return redirect('/bebidas')
# **POSTRES*
def agregar_platilloP(request, platillo, precio, cantidad, mesa):
    cantidad = nuevo_platillo(platillo, Carrito, 1)
    platillo = Carrito.objects.create(platillo=platillo, precio=precio, cantidad=cantidad, mesa=mesa, parcial=1)
    return redirect('/postres')
# **HELADO*
def agregar_platilloH(request, platillo, precio, cantidad, mesa):
    cantidad = nuevo_platillo(platillo, Carrito, 1)
    platillo = Carrito.objects.create(platillo=platillo, precio=precio, cantidad=cantidad, mesa=mesa, parcial=1)
    return redirect('/helado')
# END Eliminar y Agregar de carrito

# Agregar pedido actual a la cocina
def mandar_cocina(request):
    carrito = Carrito.objects.all() # Obtiene todos los elementos de Carrito
    if Account.objects.get(mesa=idMesa).primeraOrden == True:
        auxVar = Account.objects.filter(mesa=idMesa).update(vot=0)
    varAux = Account.objects.filter(mesa=idMesa).update(primeraOrden=False)
    for producto in carrito:
        nombre = producto.platillo
        mesaP = producto.mesa
        cant = nuevo_platillo(nombre, Orden, producto.cantidad)
        precioP = producto.precio*cant
        nuevo = Orden.objects.create(platillo=nombre, precio=precioP, cantidad=cant, mesa=mesaP, parcial=0)
    borrar_todo(Carrito, idMesa)
    ordenTotal = Orden.objects.filter(mesa=idMesa)
    cuentaTotal = 0
    for i in ordenTotal:
        cuentaTotal += i.precio
    nuevoTotal = Account.objects.filter(mesa=idMesa).update(total=cuentaTotal)
    # print(cuentaTotal)
    return redirect('/carrito', {'mensaje':"OK"})

""" Función que dado un nombre de platillo, elimina el otro y aumenta la cantidad de este
    platillo es el nombre del platillo a buscar
    tabla es la tabla en la cual se va a buscar en la base de datos
    n es el numero a agregar extra (si queremos agregar un platillo, dos, o n platillos)
"""
def nuevo_platillo(platillo, tabla, n):
    if tabla.objects.filter(platillo=platillo).exists():
        aux = tabla.objects.get(platillo=platillo)
        cantidad = aux.cantidad + n
        aux.delete()
    else:
        cantidad = n
    return cantidad

    # Poniendo nueva cantidad usando input
def usar_seleccionar(request, nuevoSelec, nombre):
    # seleccion = request.POST.getlist("cantSelPred")
    # print(seleccion)
    print(nuevoSelec)
    platActual = Carrito.objects.get(platillo=nombre)
    precio = platActual.precio
    mesa = platActual.mesa
    platActual.delete()
    platillo = Carrito.objects.create(platillo=nombre, precio=precio, cantidad=nuevoSelec, mesa=mesa, parcial=1)
    return redirect('/carrito', {'platillo':platillo})


# Agrega un contador a los platillos (ayuda a saber como nos organizamos)
def cambiar_cantidad(request):
    nombre = request.POST['platillo']
    num = request.POST.get('nuevoNum')

    if request.method == 'POST':
        # print(num)

        platillo = Carrito.objects.get(platillo=nombre)
        platillo.cantidad = num
        platillo.save()

    # return render(request, 'carrito.html')
    return redirect('/carrito')

@login_required() # ESTO ES PARA PROTEGER LA VISTA
def agregar_voto(request):
    nombreInput = request.POST.get('votacionHelado', 'nada')
    nombreComensal = request.POST.get('nombreComensal')
    heladoOpcion = request.POST.get('saboresHelado')

    if request.method == 'POST':
        # print(num)
        # print(nombreComensal)
        # print(heladoOpcion)
        helado = Helado.objects.get(nombre=heladoOpcion) # metodo filter es con query, get es de la BD
        # print(helado.count()) # Es un contador de la base de datos, ayuda a saber la longitud de la base

        if Votacion.objects.filter(helado=helado.nombre, mesa=idMesa).exists():
            aux = Votacion.objects.get(helado=helado.nombre, mesa=idMesa)
            cantidad = aux.cont + 1
            aux.delete()
        else:
            cantidad = 1

        imagen = helado.imagen
        # print(imagen)
        iceCream = Votacion.objects.create(nombre=nombreComensal, helado=heladoOpcion, imagen=imagen, mesa=idMesa, cont=cantidad)

        # Variables para obtener nombre e imagen del helado ganador
        nombreHelado = ""
        imagenHelado = ""
        mayor = 0

        # Obtenemos todos los datos de votacion al momento
        valoresVotacion = Votacion.objects.filter(mesa=idMesa)

        for i in valoresVotacion:
            if i.cont >= mayor:
                mayor = i.cont
            else:
                continue
        global contadorHelado
        contadorHelado = mayor
        totalHelados = valoresVotacion.filter(cont=mayor)
        # print(totalHelados)
        # print(str(mayor))
        
        if totalHelados.count() > 1:
            aleatorio = randrange(0, len(totalHelados))
            randomHelado = totalHelados[aleatorio]
            nombreHelado = randomHelado.helado
            imagenHelado = randomHelado.imagen
        else:
            nombreHelado = totalHelados[0].helado
            imagenHelado = totalHelados[0].imagen
        global heladoGanador
        heladoGanador = nombreHelado

    # print(heladoGanador)
    return render(request, 'voto.html', {'nombreHelado':nombreHelado, 'imagenHelado':imagenHelado})
    # return render(request, 'carrito.html')

def menu_helados(request):
    helado = Helado.objects.filter(disponibilidad=1)
    return (request, {'helado':helado})

def get_chart(_request):


    # Obteniendo objeto helado, para obtener su nombre
    helados = Helado.objects.filter(disponibilidad=1)
    datosHelado = []

    colors = ['blue', 'orange', 'black', 'red', 'yellow', 'green', 'magenta', 'lightblue', 'purple', 'brown']
    random_color = colors[randrange(0, len(colors))]

    serie = []
    counter = 0

    heladosCount = helados.count() # Cuenta cuantos helados hay en BD

    while (counter < heladosCount):
        for heladoAux in helados:
            if Votacion.objects.filter(helado=heladoAux.nombre, mesa=idMesa).exists():
                todosVotos = Votacion.objects.get(helado=heladoAux.nombre, mesa=idMesa)
                # print(str(idMesa))
                serie.append(todosVotos.cont)
                datosHelado.append(heladoAux.nombre) # Llenando la lista para el JSON, eje x de la grafica
                # print(todosVotos.count())
                # print('Existe:' + heladoAux.nombre + 'cont: ' + str(todosVotos.count()))
                heladosCount -= 1
            else:
                serie.append(0)
                datosHelado.append(heladoAux.nombre)
                # print('No existe :c' + heladoAux.nombre)
                heladosCount -= 1
    # print(serie)


    chart = {
        'tooltip': {
            'show': True,
            'trigger': "axis",
            'triggerOn': "mousemove|click"
        },
        'xAxis': [
            {
                'type': "category",
                'data': datosHelado
            }
        ],
        'yAxis': [
            {
                'type': "value"
            }
        ],
        'series': [
            {
                'data': serie,
                'type': "bar",
                'itemStyle': {
                    'color': random_color
                },
                'lineStyle': {
                    'color': random_color
                }
            }
        ]
    }

    return JsonResponse(chart)

# Redirecciona a index
def finalizar_votacion(request):
    # Borrar BD, cambiar valor voto a 1 en BD usuario, crear el nuevo helado en orden, borrar BD votacion
    nuevoVoto = Account.objects.filter(mesa=idMesa).update(vot=1)
    addHelado = 'Helado de ' + heladoGanador
    nuevoHelado = Orden.objects.create(platillo=addHelado, precio=0, cantidad=contadorHelado,mesa=idMesa,parcial=0)
    borrar_todo(Votacion, idMesa)

    return render(request, 'index.html')

#Funcion que borra todos los elementos de una tabla
def borrar_todo(tabla, mesa):
    # se_borrara = tabla.objects.filter(mesa=mesa).delete()
    se_borrara = tabla.objects.filter(mesa=mesa)
    for i in se_borrara:
        i.delete()
    return None

# Funcion que determina el total
def total_cuenta(request):
    borrar_todo(Carrito, idMesa)
    borrar_todo(Orden, idMesa)
    varAux = Account.objects.filter(mesa=idMesa).update(primeraOrden=True)
    nuevoTotal = Account.objects.filter(mesa=idMesa).update(total=0)
    return redirect('/')
