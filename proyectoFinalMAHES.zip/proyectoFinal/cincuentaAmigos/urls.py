"""proyectoFinal URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from . import views
from django.conf import settings

# from cincuentaAmigos.views import eliminar_platillo

app_name = "cincuentaAmigos" #Asignamos a app_name el nombre de nuestra app

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.index, name='index'),
    path('register/', views.RegistrationView.as_view(), name='register'),
    path('logout/', views.logout_view, name='logout'),
    #path('admin/', views.admin, name='admin'),
    # path('registro/', views.registro, name='registrooo'), // AGREGAR PARA FORMULARIO NORMAL

    path('entradas/', views.entradas, name='entradas'),
    path('fuerte/', views.fuerte, name='fuerte'),
    path('postres/', views.postres, name='postres'),
    path('bebidas/', views.bebidas, name='bebidas'),
    path('helado/', views.helado, name='helado'),
    path('carrito/', views.carrito, name='carrito'),
    path('carrito/eliminarPlatillo/<int:id>, <int:mesa>', views.eliminar_platillo, name='eliminar'), # Eliminar un platillo del carrito
    path('carrito/cambiarCantidad/', views.cambiar_cantidad, name='cambiarCantidad'), # Agrega nuevo contador al atributo contador
    path('carrito/mandarCocina', views.mandar_cocina, name='mandarCocina'),
    path('carrito/usarSeleccionar/<int:nuevoSelec>, <str:nombre>', views.usar_seleccionar, name="usarSeleccionar"),
    # Votacion de helado
    path('agregarVoto/', views.agregar_voto, name='agregarVoto'),
    path('voto/', views.voto, name='voto'),
    path('getChart/', views.get_chart, name='getChart'),
    path('voto/finalizarVotacion/', views.finalizar_votacion, name='finalizarVotacion'),
    path('voto/totalCuenta/', views.total_cuenta, name='totalCuenta'),
    # AGREGAR AL CARRITO
    path('entradas/agregarPlatillo/<str:platillo>, <int:precio>, <int:cantidad>, <int:mesa>', views.agregar_platilloE, name='agregar'), # ENTRADAS
    path('fuerte/agregarPlatillo/<str:platillo>, <int:precio>, <int:cantidad>, <int:mesa>', views.agregar_platilloF, name='agregar'), # FUERTE
    path('bebidas/agregarPlatillo/<str:platillo>, <int:precio>, <int:cantidad>, <int:mesa>', views.agregar_platilloB, name='agregar'), # BEBIDAS
    path('postres/agregarPlatillo/<str:platillo>, <int:precio>, <int:cantidad>, <int:mesa>', views.agregar_platilloP, name='agregar'), # POSTRES
    path('helado/agregarPlatillo/<str:platillo>, <int:precio>, <int:cantidad>, <int:mesa>', views.agregar_platilloH, name='agregar'), # HELADO
    # CUENTA TOTAL
    # path('carrito/agregarOrden/', views.agregar_orden, name='agregarOrden'), # HELADO
]
