from django.db import models
from django.contrib.auth.models import AbstractBaseUser, BaseUserManager, PermissionsMixin
from django.contrib.auth import get_user_model
from django.utils import timezone

# Create your models here.
class AccountManager(BaseUserManager):
    use_in_migrations = True

    def _create_user(self, mesa, ubicacion, password, **extra_fields):
        values = [mesa, ubicacion]
        field_value_map = dict(zip(self.model.REQUIRED_FIELDS, values))
        for field_name, value in field_value_map.items():
            if not value:
                raise ValueError('The {} value must be set'.format(field_name))
        #mesa = self.normalize_mesa(mesa)
        user = self.model(
            mesa=mesa,
            ubicacion=ubicacion,
            **extra_fields
        )
        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_user(self, mesa, ubicacion,password=None, **extra_fields):
        extra_fields.setdefault('is_staff', False)
        extra_fields.setdefault('is_superuser', False)
        return self._create_user(mesa, ubicacion, ubicacion, **extra_fields)

    def create_superuser(self, mesa, ubicacion,password=None, **extra_fields):
        extra_fields.setdefault('is_staff', True)
        extra_fields.setdefault('is_superuser', True)

        if extra_fields.get('is_staff') is not True:
            raise ValueError('Superuser must have is_staff=True.')
        if extra_fields.get('is_superuser') is not True:
            raise ValueError('Superuser must have is_superuser=True.')

        return self._create_user(mesa, ubicacion, password, **extra_fields)


class Account(AbstractBaseUser, PermissionsMixin):
    mesa = models.CharField(unique=True,max_length=150)
    ubicacion = models.CharField(max_length=150)
    is_staff = models.BooleanField(default=False)
    is_active = models.BooleanField(default=True)
    date_joined = models.DateTimeField(default=timezone.now)
    last_login = models.DateTimeField(null=True)
    vot = models.BooleanField(default=True)
    primeraOrden = models.BooleanField(default=True)
    total = models.IntegerField(default=0)

    objects = AccountManager()

    USERNAME_FIELD = 'mesa'
    REQUIRED_FIELDS = ['ubicacion']



class  Entradas(models.Model):
    imagen  =  models.CharField(default=" ", max_length=1000)
    precio =  models.IntegerField(default=0)
    nombre  =  models.CharField(max_length=200)
    descripcion =  models.TextField(default=" ", max_length=1000)
    disponibilidad = models.IntegerField(default=0)

    # Metodo toString
    def __str__(self):
        return f'Nombre: {self.nombre}. ${self.precio}'

class  Fuerte(models.Model):
    imagen  =  models.CharField(default=" ", max_length=1000)
    precio =  models.IntegerField(default=0)
    nombre  =  models.CharField(default=" ", max_length=1000)
    descripcion =  models.TextField(default=" ", max_length=1000)
    disponibilidad = models.IntegerField(default=0)

    # Metodo toString
    def __str__(self):
        return f'Nombre: {self.nombre}. ${self.precio}'

class  Bebidas(models.Model):
    imagen  =  models.CharField(default=" ", max_length=1000)
    precio =  models.IntegerField(default=0)
    nombre  =  models.CharField(default=" ", max_length=1000)
    descripcion =  models.TextField(default=" ", max_length=1000)
    disponibilidad = models.IntegerField(default=0)

    # Metodo toString
    def __str__(self):
        return f'Nombre: {self.nombre}. ${self.precio}'

class  Postres(models.Model):
    imagen  =  models.CharField(default=" ", max_length=1000)
    precio =  models.IntegerField(default=0)
    nombre  =  models.CharField(default=" ", max_length=1000)
    descripcion =  models.TextField(default=" ", max_length=1000)
    disponibilidad = models.IntegerField(default=0)

    # Metodo toString
    def __str__(self):
        return f'Nombre: {self.nombre}. ${self.precio}'

class  Helado(models.Model):
    imagen  =  models.CharField(default=" ", max_length=1000)
    precio =  models.IntegerField(default=0)
    nombre  =  models.CharField(default=" ", max_length=1000)
    descripcion =  models.TextField(default=" ", max_length=1000)
    disponibilidad = models.IntegerField(default=0)

    # Metodo toString
    def __str__(self):
        return f'Nombre: {self.nombre}. ${self.precio}'

class Carrito(models.Model):
    platillo = models.CharField(default=" ", max_length=200)
    precio = models.IntegerField(default=1)
    cantidad = models.IntegerField(default=1)
    contador = models.IntegerField(default=0)
    mesa = models.IntegerField(default=0)
    parcial = models.IntegerField(default=1)

    def __str__(self):
        return f'{self.platillo}, ${self.precio}.00'

class Orden(models.Model):
    platillo = models.CharField(default=" ", max_length=200)
    precio = models.IntegerField(default=1)
    cantidad = models.IntegerField(default=1)
    contador = models.IntegerField(default=0)
    mesa = models.IntegerField(default=0)
    parcial = models.IntegerField(default=0)

    def __str__(self):
        return f'{self.platillo}, ${self.precio}.00'

class Votacion(models.Model):
    helado = models.CharField(default="", max_length=200)
    imagen = models.CharField(default="", max_length=200)
    nombre = models.CharField(default="", max_length=200)
    mesa = models.IntegerField(default=0)
    cont = models.IntegerField(default=0)

    def __str__(self):
        return f'{self.nombre}, {self.helado}'